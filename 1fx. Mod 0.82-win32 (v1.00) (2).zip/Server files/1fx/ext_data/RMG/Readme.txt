// Boe!Man 11/5/12

These RMG files are needed in order to play RMG maps under H&S/H&Z.
You should not change these files, you can, however, decide to edit the entity files.

If you do wish to change the mission files, please know that the h&s, h&z and inf mission files should represent the same settings.
If you do not do this, random crashes might occur or people might get kicked. Always keep these files in sync.
You can find the inf_*.mission files in the mp.pk3 archive.