RPM + extended MVCHAT file
==========================
This file contains extra sounds present in the RPM soundpack,
followed by the extended sounds.

An RPM client is required client-side to use the RPM sounds
in this MVCHAT file. No additional soundpacks are required
for the extended sounds.
The sounds defined in this file are 111 up to 240.

Installation
============
- Put the "rpm + extended.mvchat" file in your 1fx/files/mvchats directory.
- Delete the "extended.mvchat" file from your 1fx/files/mvchats directory.
