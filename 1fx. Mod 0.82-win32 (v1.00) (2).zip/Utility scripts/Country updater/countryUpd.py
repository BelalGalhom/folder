#!/usr/bin/python3
### ================================ ###
###  Country database update script  ###
###    Version 1.00 - Feb 17 2017    ###
###       Developed by Boe!Man       ###
### Part of 1fx. Mod Utility scripts ###
### ================================ ###

import os
import os.path
import sys
import urllib.request
import shutil
import gzip
import sqlite3

# ===================
# Global definitions.
# ===================

# The URL of the country database. When an alternative URL is specified,
# ensure it's either a mirror or has compatibility with the database from
# software77.
# The database downloaded can either be .csv (not supported directly from
# software77), or a .gz file which can be decompressed (default).
DATABASE_URL = "http://software77.net/geo-ip/?DL=1" # IpToCountry.csv.gz (IPv4)

# If the specified database file is a gzip compressed file, set this to True.
IS_GZIPPED = True

# ===================
# Global functions.
# ===================

def cleanUpAndExit(exitCode):
    # Close database file if opened.
    if(db != None):
        db.commit()
        db.close()
    
    # Remove created files, if downloaded/created properly.
    if(os.path.exists("db.csv")):
        os.remove("db.csv")
    if(os.path.exists("db.gz")):
        os.remove("db.gz")
    
    print(os.linesep)
    input("Press Enter to exit..")
    sys.exit(exitCode)

# ===================

def fileLineLength(fileName):
    with open(fileName, "rb") as f:
        for i, l in enumerate(f):
            pass
    return i + 1

# ===================

# Percentage displayed.
percDisplayed = 0

def printPercentage(num, goal, step):
    global percDisplayed
    
    perc = (int)(100 / goal * num)
    if(perc >= (percDisplayed + step)):
        print("%d%s.." % (perc, "%"), end = "", flush = True)
        percDisplayed += step
    
    # Reset counter when we hit 100%.
    if(percDisplayed == 100):
        percDisplayed = 0

# ===================

# The total table count.
tableCount = 0
# Table row limit.
table_rowLimit = 1000
# The current table row count. Keep in sync with the table_rowLimit
# to force the first table being created properly.
table_rowCount = 1000
# The table beginIp we want to remember for the table overview.
table_beginIp = 0
# The table endIp we want to remember for the table overview.
table_endIp = 0

def insertCountryData(db, beginIp, endIp, ext, country):
    global tableCount
    global table_rowLimit
    global table_rowCount
    global table_beginIp
    global table_endIp
    
    # Check if we're at the limit of this table.
    if(table_rowCount == table_rowLimit):
        # Register the previous entry in the country_index table,
        # unless it's the first one.
        insVars = []
        if(tableCount != 0):
            c.execute("INSERT INTO country_index VALUES (?, ?, ?)", 
                [table_beginIp, table_endIp, tableCount])

        # Increase table count.
        tableCount += 1
        
        # Create new table in the database.
        c.execute("CREATE TABLE db%d(\"begin_ip\" INT64, \"end_ip\" INT64" \
            ", \"ext\" varchar(4), \"country\" varchar(32))" % (tableCount))

        # Reset table row count check.
        table_rowCount = 0
            
        # The beginIp to remember is of this initial record.
        table_beginIp = beginIp
    
    # Insert country data into the database.
    c.execute("INSERT INTO db%d VALUES (?, ?, ?, ?)" 
        % (tableCount), [beginIp, endIp, ext, country])
    
    table_rowCount += 1
    table_endIp = endIp

# ===================
# Script routine.
# ===================

# Make sure the db variable is initialized.
db = None

# ==============
# Print script header.
# ==============

print("================================")
print("Country database update script")
print("Version 1.00 - Feb 17 2017")
print("Part of 1fx. Mod Utility scripts")
print("================================")

# ==============
# Remove previously created database, if present.
# ==============

if(os.path.exists("country.db")):
    os.remove("country.db")

# ==============
# Download country archive/file.
# ==============

# Download the country file from the URL as specified.
if(IS_GZIPPED):
    outFile = "db.gz"
else:
    outFile = "db.csv"

# Download the country file.
print("Downloading the country file.. ", end = "", flush = True)

try:
    with urllib.request.urlopen(DATABASE_URL) as response, \
        open(outFile, "wb") as out_file:
            try:
                shutil.copyfileobj(response, out_file)
            except IOException as e:
                print ("ERROR while writing the country database!")
                print("Reason: %s" % (e))
                cleanUpAndExit(1)
except Exception as e:
    print("fail!")
    print("ERROR downloading the country database.")
    print("Reason: %s" % (e))
    cleanUpAndExit(1)

print("done!")

# ==============
# Decompress country archive if necessary.
# ==============

# Done downloading the country file, decompress the .gz file if necessary.
if(IS_GZIPPED):
    print("Decompressing the gzip archive.. ", end = "", flush = True)

    # Decompress the actual file.
    try:
        with open(outFile, 'rb') as compressedFile:
            with open("db.csv", 'wb') as decompressedFile:
                decompressedFile.write(gzip.decompress(compressedFile.read()))
    except IOError as e:
        print("fail!")
        print("ERROR decompressing country gzip file.")
        print("Reason: %s" % (e))
        cleanUpAndExit(1)

    print("done!")

# ==============
# Create database.
# ==============

# Create database connection.
print("Creating the country.db file.. ", end = "", flush = True)

try:
    db = sqlite3.connect("country.db")
    c = db.cursor()

    # Create country_index table.
    c.execute("CREATE TABLE country_index" \
        "(\"begin_ip\" INT64,\"end_ip\" INT64, \"table_index\" INT(4))")
except Exception as e:
    print("fail!")
    print("ERROR creating SQLite country.db file.")
    print("Reason: %s" % (e))
    cleanUpAndExit(1)

print("done!", os.linesep)

# ==============
# Process country file.
# ==============

print("Converting country file to database format.. ", end = "", flush = True)

# Determine line length up-front, to show an indication while parsing.
lineLen = fileLineLength("db.csv")

# The following variables are used for the indication bar/statistics.
lineCount = 0
insertCount = 0
reserveCount = 0

# Open the country file in read/binary mode.
dbFile = open("db.csv", "rb")

# Now iterate through the file, line by line.
for line in dbFile:
    # Update indicator.
    lineCount += 1
    printPercentage(lineCount, lineLen, 5)
    
    # Determine first character of the line.
    char = chr(line[0])
    
    # Skip whitespace / comments.
    if(char == "#" or char == "\t" or char == " "):
        continue
    
    # Now decode the line properly.
    line = line.decode("utf-8")
    
    # Also strip the whitespace and the remove double quotes
    # from the existing line.
    line = line.strip(None)
    line = line.replace("\"", "")
    
    # Split the line.
    blocks = line.split(",")
    
    # Insert the data in the database, unless it's a reserved space.
    if(blocks[4] != "ZZ"):
        insertCountryData(db, blocks[0], blocks[1], blocks[4], blocks[6])
        insertCount += 1
    else:
        reserveCount += 1

# Done, now write the final index to the country_index table.
c.execute("INSERT INTO country_index VALUES (?, ?, ?)", 
    [table_beginIp, table_endIp, tableCount])

print(" done!", os.linesep)

# Display statistics.
print("Inserted %d IP ranges into the database." % (insertCount))
print("Skipped %d reserved IP ranges." % (reserveCount))
print("Skipped %d whitespace/comment lines from country file."
    % (lineCount - insertCount - reserveCount))

# ==============
# End of routine.
# ==============

cleanUpAndExit(0)
