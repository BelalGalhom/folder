#!/usr/bin/python3
### ================================ ###
###    Inview to db parser script    ###
###    Version 1.00 - Jul 30 2017    ###
###       Developed by Boe!Man       ###
### Part of 1fx. Mod Utility scripts ###
### ================================ ###

import os
import os.path
import sys
import re
import sqlite3

# ===================
# Global functions.
# ===================

def cleanUpAndExit(exitCode):
    removedDb = False

    # Close database file if opened.
    if(db != None):
        db.commit()
        db.close()

        if(exitCode != 0):
            if(os.path.exists("inview.db")):
                os.remove("inview.db")
                removedDb = True

    print(os.linesep)
    if(removedDb):
        print("Removed faulty/incomplete inview.db file due to errors.")

    input("Press Enter to exit..")
    sys.exit(exitCode)

# ===================

def getWeaponNum(weapName):
    try:
        return weapons.index(weapName)
    except ValueError:
        return -1

# ===================
# Script routine.
# ===================

# Make sure the db variable is initialized.
db = None

# ==============
# Print script header.
# ==============

print("================================")
print("Inview to db parser script")
print("Version 1.00 - Jul 30 2017")
print("Part of 1fx. Mod Utility scripts")
print("================================")

# ==============
# Check if SOF2.inview file is present,
# or sof2.inview for Demo.
# ==============

if(os.path.exists("SOF2.inview") == False
    and os.path.exists("sof2.inview") == False):
    print("A SOF2.inview or sof2.inview file is not present, not continuing..")
    cleanUpAndExit(1)

# ==============
# If a previous database is present, we will either delete or exit.
# ==============

if(os.path.exists("inview.db")):
    print("An inview.db file is already present in the current directory.")
    print("To continue, we will have to delete this database file.")
    print("Is this okay?", os.linesep)
    ch = input("Yes or no (Y/n): ")

    if("n" in ch):
        print("Not continuing.")
        cleanUpAndExit(1)

    os.remove("inview.db")
    print("Database removed.", os.linesep)

# ==============
# Check what SoF2 platform to convert for.
# ==============

# If we use weapons from Gold or Full.
goldWeaps = False

print("Select what SoF2 platform you want to convert for.")
print(" 1. SoF2 v1.02t (MP TEST) or SoF2 v1.00 (Full)")
print(" 2. SoF2 v1.02/v1.03 (Gold)", os.linesep)
ch = input("Choose 1-2 [1]: ")
if("2" in ch):
    goldWeaps = True

if(goldWeaps == True):
    print("Database will be compatible with SoF2 v1.03 (Gold).", os.linesep)
else:
    print("Database will be compatible with SoF2 v1.02t (MP TEST) " \
        "and SoF2 v1.00 (Full).", os.linesep)

# ==============
# Define weapon names and IDs.
# ==============

# Define weapons now we know what to convert for.
weapons = []
if(goldWeaps == False):
    # v1.00/v1.02t weapons.
    weapons.extend((
        "No Weapon",            # WP_NONE,
        "Knife",                # WP_KNIFE,
        "M1911A1",              # WP_M1911A1_PISTOL,
        "US SOCOM",             # WP_US_SOCOM_PISTOL,
        "M590",                 # WP_M590_SHOTGUN,
        "Micro Uzi",            # WP_MICRO_UZI_SUBMACHINEGUN,
        "M3A1",                 # WP_M3A1_SUBMACHINEGUN,
        "USAS-12",              # WP_USAS_12_SHOTGUN,
        "M4",                   # WP_M4_ASSAULT_RIFLE,
        "AK74",                 # WP_AK74_ASSAULT_RIFLE,
        "MSG90A1",              # WP_MSG90A1_SNIPER_RIFLE,
        "M60",                  # WP_M60_MACHINEGUN,
        "MM1",                  # WP_MM1_GRENADE_LAUNCHER,
        "RPG7",                 # WP_RPG7_LAUNCHER,
        "M67",                  # WP_M67_GRENADE,
        "M84",                  # WP_M84_GRENADE,
        "F1",                   # WP_F1_GRENADE,
        "L2A2",                 # WP_L2A2_GRENADE,
        "MDN11",                # WP_MDN11_GRENADE,
        "SMOHG92",              # WP_SMOHG92_GRENADE,
        "ANM14",                # WP_ANM14_GRENADE,
        "M15"                   # WP_M15_GRENADE
    ))
else:
    # v1.03 weapons, plus v1.00 weapons present in the 1fx. Client Additions.
    weapons.extend((
        "No Weapon",            # WP_NONE,
        "Knife",                # WP_KNIFE,
        "M1911A1",              # WP_M1911A1_PISTOL,
        "US SOCOM",             # WP_US_SOCOM_PISTOL,
        "Silver Talon",         # WP_SILVER_TALON,
        "M590",                 # WP_M590_SHOTGUN,
        "Micro Uzi",            # WP_MICRO_UZI_SUBMACHINEGUN,
        "M3A1",                 # WP_M3A1_SUBMACHINEGUN,
        "MP5",                  # WP_MP5
        "USAS-12",              # WP_USAS_12_SHOTGUN,
        "M4",                   # WP_M4_ASSAULT_RIFLE,
        "AK74",                 # WP_AK74_ASSAULT_RIFLE,
        "Sig 551",              # WP_SIG551
        "MSG90A1",              # WP_MSG90A1_SNIPER_RIFLE,
        "M60",                  # WP_M60_MACHINEGUN,
        "MM1",                  # WP_MM1_GRENADE_LAUNCHER,
        "RPG7",                 # WP_RPG7_LAUNCHER,
        "M84",                  # WP_M84_GRENADE,
        "SMOHG92",              # WP_SMOHG92_GRENADE,
        "ANM14",                # WP_ANM14_GRENADE,
        "M15",                  # WP_M15_GRENADE
        "M67",                  # WP_M67_GRENADE,
        "F1",                   # WP_F1_GRENADE,
        "L2A2",                 # WP_L2A2_GRENADE,
        "MDN11"                 # WP_MDN11_GRENADE

    ))

# ==============
# Create database.
# ==============

# Create database connection.
print("Creating initial inview.db structure.. ", end = "", flush = True)

try:
    db = sqlite3.connect("inview.db")
    c = db.cursor()

    # Create initial database structure.
    c.execute(re.sub(" +", " ", "CREATE TABLE weapons(" \
                "ID                     INT," \
                "name                   VARCHAR(32));"))

    c.execute(re.sub(" +", " ", "CREATE TABLE weaponmodel(" \
                "WEAPON_ID              INT," \
                "name                   VARCHAR(32)," \
                "model                  VARCHAR(128)," \
                "frames                 VARCHAR(128));"))
                
    c.execute(re.sub(" +", " ", "CREATE TABLE weapon_anim(" \
                "WEAPON_ID              INT," \
                "ANIM_ID                INT," \
                "name                   VARCHAR(16));"))

    c.execute(re.sub(" +", " ", "CREATE TABLE weapon_anim_info(" \
                "ANIM_ID                INT," \
                "type                   VARCHAR(32)," \
                "name                   VARCHAR(32)," \
                "anim                   VARCHAR(32)," \
                "anim1                  VARCHAR(32)," \
                "anim2                  VARCHAR(32)," \
                "anim3                  VARCHAR(32)," \
                "anim4                  VARCHAR(32)," \
                "animNoLerp1            VARCHAR(32)," \
                "animNoLerp2            VARCHAR(32)," \
                "animNoLerp3            VARCHAR(32)," \
                "animNoLerp4            VARCHAR(32)," \
                "extra1                 VARCHAR(16)," \
                "extra2                 VARCHAR(16)," \
                "extra3                 VARCHAR(16)," \
                "speed                  FLOAT," \
                "mp_speed               FLOAT," \
                "lodbias                INT," \
                "extraNoLerp1           VARCHAR(32)," \
                "transition1            VARCHAR(32)," \
                "transition2            VARCHAR(32)," \
                "transition3            VARCHAR(32)," \
                "end1                   VARCHAR(32)," \
                "end2                   VARCHAR(32)," \
                "end3                   VARCHAR(32));"))

except Exception as e:
    print("fail!")
    print("ERROR creating SQLite inview.db structure.")
    print("Reason: %s" % (e))
    cleanUpAndExit(1)

print("done!")

# ==============
# Process inview file.
# ==============

# Open the inview file in read mode.
if(os.path.exists("SOF2.inview")):
    dbFile = open("SOF2.inview", "r")
else:
    dbFile = open("sof2.inview", "r")

# The following variables are used while iterating through the file.
blockDepth = 0
parseBlock = False
parsedBlocks = []
parsedBlocksPrev = []
parsedBlocksCount = 0
prevBlocksNum = -1
prevLine = ""
weapNum = -1
newBlock = False

# The following variable is used to keep track of some IDs in tables.
animNum = -1

# The following variables are used for the statistics.
weapsParsed = []
weapsNotParsed = []

print("Converting inview file.. ", end = "", flush = True)

# Now iterate through the file, line by line.
for line in dbFile:
    # Variables for when parsing the file.
    key = ""
    keyVal = ""

    # Strip whitespace.
    line = line.strip(None)

    # Continue if we've got an empty line.
    if(len(line) == 0):
        continue

    # Check if we're parsing a new block, or closing an old one.
    if("{" in line):
        if(blockDepth == 0):
            parseBlock = "weapon" in prevLine

        blockDepth += 1
        parsedBlocks.append(prevLine)
        prevLine = line
        continue
    elif("}" in line):
        blockDepth -= 1
        parsedBlocks.pop()
        prevLine = line
        parsedBlocksCount += 1
        continue

    # Save a copy of the current line, so we can use it in the next one.
    prevLine = line

    # Don't continue if we've got nothing to check anyway.
    if(parseBlock == False):
        continue

    # Only parse keys.
    if(not("\t" in line) and line.count(" ") != 1):
        continue

    # Get key/value combination.
    if("\t" in line):
        keyValTemp = line.split("\t")
    else:
        keyValTemp = line.split(" ")

    key = keyValTemp[0]
    keyVal = keyValTemp[-1]

    # Strip whitespace from beginning and end of key and key value.
    key = key.strip()
    keyVal = keyVal.strip()

    # Determine lowercase string of the key.
    keyLower = key.lower()

    # Strip quotes from string, if present.
    keyVal = keyVal.replace("\"", "")

    # Determine if this is a new block.
    newBlock = (prevBlocksNum != parsedBlocksCount
        or parsedBlocksPrev != parsedBlocks)

    # Iterate through the data.
    if(blockDepth == 1):
        if(keyLower == "name"):
            weapNum = getWeaponNum(keyVal)

            if(weapNum == -1):
                # Don't parse this weapon.
                parseBlock = False

                # Keep track of weapons not being parsed.
                weapsNotParsed.append(keyVal)
            else:
                # Insert this number and name into the database.
                c.execute("INSERT INTO weapons VALUES (?, ?);",
                    [weapNum, keyVal]);

                # Keep track of weapons parsed.
                weapsParsed.append([keyVal, weapNum])
    elif(blockDepth == 2):
        # Weapon models (base).
        if(parsedBlocks[1] == "weaponmodel"):
            if(newBlock):
                c.execute("INSERT INTO weaponmodel (WEAPON_ID, '%s') " \
                    "VALUES(?, ?);" % (keyLower), [weapNum, keyVal])
            else:
                c.execute("UPDATE weaponmodel SET %s=? WHERE WEAPON_ID=?"
                    % (keyLower), [keyVal, weapNum])
        # Anims (base).
        elif(parsedBlocks[1] == "anim"):
            # Anim base only consists of one valid key (name).
            if(keyLower == "name"):
                animNum += 1

                c.execute("INSERT INTO weapon_anim VALUES(?, ?, ?)",
                    [weapNum, animNum, keyVal])
    elif(blockDepth == 3):
        # Anims.
        if(parsedBlocks[1] == "anim"):
            if(parsedBlocks[2] == "info"):
                if(newBlock):
                    # Insert new row.
                    c.execute("INSERT INTO weapon_anim_info (ANIM_ID) " \
                        "VALUES (?)", [animNum])

                    prevBlocksNum = parsedBlocksCount

                # Update weapon info.
                c.execute("UPDATE weapon_anim_info SET %s=?" \
                 "WHERE ROWID=(SELECT MAX(ROWID) FROM weapon_anim_info);"
                 % (keyLower), [keyVal])

    # Save a copy of this lines parsed blocks and count.
    # We use this to determine on the next line if a new block opened,
    # so we can update accordingly.
    parsedBlocksPrev = parsedBlocks[:]
    prevBlocksNum = parsedBlocksCount

# Close the inview file.
dbFile.close()

if(blockDepth == 0):
    print("done!", os.linesep)

    if(len(weapsParsed) > 0):
        # Display statistics of parsed weapons.
        weapColWidth = 7
        weapMaxWidth = 0

        # Determine longest name.
        for w in weapsParsed:
            if(len(w[0]) > weapMaxWidth):
                weapMaxWidth = len(w[0])

        if(weapMaxWidth > 7):
            # Longer than the default, adjust our column width.
            weapColWidth = weapMaxWidth + 1

        print("Inserted %d parsed weapons into the database:"
            % (len(weapsParsed)), os.linesep)

        # Print table.
        # Header.
        print("+", "-" * (weapColWidth + 1), "+", "-" * 4, "+")
        print("| ", "Weapon".ljust(weapColWidth),  "|  ID  |")
        print("+", "-" * (weapColWidth + 1), "+", "-" * 4, "+")

        # Body.
        for w in weapsParsed:
            print("| ", w[0].ljust(weapColWidth), "| ",
                str(w[1]).ljust(3), "|")

        # Footer.
        print("+", "-" * (weapColWidth + 1), "+", "-" * 4, "+", os.linesep)

    if(len(weapsNotParsed) > 0):
        # Display statistics of skipped weapons.
        weapColWidth = 7
        weapMaxWidth = 0

        # Determine longest name.
        if(len(max(weapsNotParsed, key=len)) > 6):
            # Longer than the default, adjust our column width.
            weapColWidth = len(max(weapsNotParsed, key=len)) + 1

        print("Skipped parsing %d incompatible weapons:"
            % (len(weapsNotParsed)), os.linesep)

        # Print table.
        # Header.
        print("+", "-" * (weapColWidth + 1), "+")
        print("| ", "Weapon".ljust(weapColWidth),  "|")
        print("+", "-" * (weapColWidth + 1), "+")

        # Body.
        for w in weapsNotParsed:
            print("| ", w.ljust(weapColWidth), "|")

        # Footer.
        print("+", "-" * (weapColWidth + 1), "+")
else:
    print("fail!")

    if(abs(blockDepth) == 1):
        suffix = " is"
    else:
        suffix = "s are"

    if(blockDepth > 0):
        print("ERROR: The file contains %d blocks that aren't closed." \
            "%s%d '}' character%s missing somewhere."
            % (blockDepth, os.linesep, blockDepth, suffix))
    else:
        print("ERROR: The file contains %d blocks that are closed without " \
            "being open.%s%d '{' character%s missing somewhere."
            % (blockDepth * -1, os.linesep, blockDepth * -1, suffix))

    cleanUpAndExit(1)

# ==============
# End of routine.
# ==============

cleanUpAndExit(0)
